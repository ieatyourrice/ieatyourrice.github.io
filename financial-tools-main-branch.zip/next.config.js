
module.exports = {
  output: 'export',
  basePath: '/',
};
